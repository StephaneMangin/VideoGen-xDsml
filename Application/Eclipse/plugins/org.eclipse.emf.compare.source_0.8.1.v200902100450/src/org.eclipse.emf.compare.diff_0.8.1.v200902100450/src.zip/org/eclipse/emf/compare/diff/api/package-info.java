/*
 * (non-javadoc)
 * Copyright (c) 2006, 2007, 2008 Obeo.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Obeo - initial API and implementation
 */
/**
 * This packages provides the interface that can be implemented by clients
 * to define their own diff engine.
 */
package org.eclipse.emf.compare.diff.api;