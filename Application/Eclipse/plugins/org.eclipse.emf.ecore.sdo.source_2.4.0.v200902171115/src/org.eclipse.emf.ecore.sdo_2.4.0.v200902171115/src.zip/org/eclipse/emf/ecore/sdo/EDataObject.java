/**
 * <copyright>
 *
 * Copyright (c) 2003-2006 IBM Corporation and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *   IBM - Initial API and implementation
 *
 * </copyright>
 *
 * $Id: EDataObject.java,v 1.8 2007/06/12 15:06:34 emerks Exp $
 */
package org.eclipse.emf.ecore.sdo;

import org.eclipse.emf.ecore.EObject;

import commonj.sdo.DataObject;
import commonj.sdo.Property;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EData Object</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emf.ecore.sdo.SDOPackage#getEDataObject()
 * @model superTypes="org.eclipse.emf.ecore.EObject org.eclipse.emf.ecore.sdo.DataObject"
 * @generated
 */
public interface EDataObject extends EObject, DataObject
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model kind="operation" dataType="org.eclipse.emf.ecore.sdo.EJavaList<org.eclipse.emf.ecore.sdo.Property>" many="false"
   *        annotation="http://www.eclipse.org/emf/2002/GenModel body='return <%org.eclipse.emf.ecore.sdo.util.SDOUtil%>.getInstanceProperties(this);'"
   * @generated
   */
  List<Property> getInstanceProperties();

} // EDataObject
