/**
 * <copyright>
 * </copyright>
 *
 * $Id: ImplSingleRefContainerNPL.java,v 1.2 2008/07/10 15:57:40 estepper Exp $
 */
package org.eclipse.emf.cdo.tests.model4;

import org.eclipse.emf.cdo.tests.model4interfaces.ISingleRefContainerNPL;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Impl Single Ref Container NPL</b></em>'. <!--
 * end-user-doc -->
 * 
 * @see org.eclipse.emf.cdo.tests.model4.model4Package#getImplSingleRefContainerNPL()
 * @model
 * @generated
 */
public interface ImplSingleRefContainerNPL extends ISingleRefContainerNPL
{
} // ImplSingleRefContainerNPL
