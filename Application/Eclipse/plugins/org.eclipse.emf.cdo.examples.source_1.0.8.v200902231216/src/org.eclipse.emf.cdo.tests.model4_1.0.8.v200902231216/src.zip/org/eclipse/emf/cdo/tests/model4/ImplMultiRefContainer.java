/**
 * <copyright>
 * </copyright>
 *
 * $Id: ImplMultiRefContainer.java,v 1.2 2008/07/10 15:57:40 estepper Exp $
 */
package org.eclipse.emf.cdo.tests.model4;

import org.eclipse.emf.cdo.tests.model4interfaces.IMultiRefContainer;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Impl Multi Ref Container</b></em>'. <!--
 * end-user-doc -->
 * 
 * @see org.eclipse.emf.cdo.tests.model4.model4Package#getImplMultiRefContainer()
 * @model
 * @generated
 */
public interface ImplMultiRefContainer extends IMultiRefContainer
{
} // ImplMultiRefContainer
