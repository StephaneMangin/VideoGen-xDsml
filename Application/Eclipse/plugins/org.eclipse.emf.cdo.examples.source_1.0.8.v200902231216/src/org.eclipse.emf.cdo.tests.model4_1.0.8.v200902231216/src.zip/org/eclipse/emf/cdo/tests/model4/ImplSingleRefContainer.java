/**
 * <copyright>
 * </copyright>
 *
 * $Id: ImplSingleRefContainer.java,v 1.2 2008/07/10 15:57:40 estepper Exp $
 */
package org.eclipse.emf.cdo.tests.model4;

import org.eclipse.emf.cdo.tests.model4interfaces.ISingleRefContainer;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Impl Single Ref Container</b></em>'. <!--
 * end-user-doc -->
 * 
 * @see org.eclipse.emf.cdo.tests.model4.model4Package#getImplSingleRefContainer()
 * @model
 * @generated
 */
public interface ImplSingleRefContainer extends ISingleRefContainer
{
} // ImplSingleRefContainer
