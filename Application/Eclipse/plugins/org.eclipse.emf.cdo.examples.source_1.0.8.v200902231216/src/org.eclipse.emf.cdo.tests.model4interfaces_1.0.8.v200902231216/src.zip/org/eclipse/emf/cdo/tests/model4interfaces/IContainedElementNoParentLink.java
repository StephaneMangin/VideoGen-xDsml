/**
 * <copyright>
 * </copyright>
 *
 * $Id: IContainedElementNoParentLink.java,v 1.2 2008/07/10 15:57:45 estepper Exp $
 */
package org.eclipse.emf.cdo.tests.model4interfaces;

import org.eclipse.emf.cdo.CDOObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>IContained Element No Parent Link</b></em>'.
 * <!-- end-user-doc -->
 * 
 * @see org.eclipse.emf.cdo.tests.model4interfaces.model4interfacesPackage#getIContainedElementNoParentLink()
 * @model interface="true" abstract="true"
 * @extends CDOObject
 * @generated
 */
public interface IContainedElementNoParentLink extends CDOObject
{
} // IContainedElementNoParentLink
