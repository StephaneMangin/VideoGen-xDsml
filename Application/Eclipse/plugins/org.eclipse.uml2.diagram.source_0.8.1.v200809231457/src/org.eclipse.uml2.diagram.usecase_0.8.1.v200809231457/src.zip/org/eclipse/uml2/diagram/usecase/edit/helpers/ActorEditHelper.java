package org.eclipse.uml2.diagram.usecase.edit.helpers;

/**
 * @generated
 */
public class ActorEditHelper extends UMLBaseEditHelper {
}
