package org.eclipse.uml2.diagram.usecase.edit.helpers;

/**
 * @generated
 */
public class ElementImportEditHelper extends UMLBaseEditHelper {
}
