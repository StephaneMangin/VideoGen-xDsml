package org.eclipse.uml2.diagram.usecase.edit.helpers;

/**
 * @generated
 */
public class DependencyEditHelper extends UMLBaseEditHelper {
}
