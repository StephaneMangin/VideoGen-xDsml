package org.eclipse.uml2.diagram.deploy.edit.helpers;

/**
 * @generated
 */
public class NodeEditHelper extends UMLBaseEditHelper {
}
