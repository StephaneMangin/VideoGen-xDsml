package org.eclipse.uml2.diagram.clazz.edit.helpers;

import org.eclipse.gmf.runtime.emf.type.core.edithelper.AbstractEditHelperAdvice;

/**
 * @generated
 */
public class ClassEditHelperAdvice extends AbstractEditHelperAdvice {
}