package org.eclipse.uml2.diagram.activity.edit.helpers;

/**
 * @generated
 */
public class OutputPinEditHelper extends UMLBaseEditHelper {
}
