package org.eclipse.uml2.diagram.activity.edit.helpers;

/**
 * @generated
 */
public class ObjectFlowEditHelper extends UMLBaseEditHelper {
}
