/**
 * <copyright>
 * </copyright>
 *
 * $Id: RotatedLabelAttributesImpl.java,v 1.1 2008/09/05 19:40:28 mgolubev Exp $
 */
package org.eclipse.uml2.diagram.codegen.gmfgenext.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.uml2.diagram.codegen.gmfgenext.GMFGenExtPackage;
import org.eclipse.uml2.diagram.codegen.gmfgenext.RotatedLabelAttributes;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Rotated Label Attributes</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class RotatedLabelAttributesImpl extends EObjectImpl implements RotatedLabelAttributes {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RotatedLabelAttributesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return GMFGenExtPackage.Literals.ROTATED_LABEL_ATTRIBUTES;
	}

} //RotatedLabelAttributesImpl
