/**
 * <copyright>
 * </copyright>
 *
 * $Id: DynamicCanonicalCompartment.java,v 1.1 2008/05/07 17:36:56 mgolubev Exp $
 */
package org.eclipse.uml2.diagram.codegen.gmfgenext;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dynamic Canonical Compartment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.uml2.diagram.codegen.gmfgenext.GMFGenExtPackage#getDynamicCanonicalCompartment()
 * @model
 * @generated
 */
public interface DynamicCanonicalCompartment extends AbstractDynamicCanonicalContainer {
} // DynamicCanonicalCompartment
