/**
 * <copyright>
 * </copyright>
 *
 * $Id: RotatedLabelAttributes.java,v 1.1 2008/09/05 19:40:29 mgolubev Exp $
 */
package org.eclipse.uml2.diagram.codegen.gmfgenext;

import org.eclipse.gmf.codegen.gmfgen.Attributes;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rotated Label Attributes</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.uml2.diagram.codegen.gmfgenext.GMFGenExtPackage#getRotatedLabelAttributes()
 * @model
 * @generated
 */
public interface RotatedLabelAttributes extends Attributes {
} // RotatedLabelAttributes
