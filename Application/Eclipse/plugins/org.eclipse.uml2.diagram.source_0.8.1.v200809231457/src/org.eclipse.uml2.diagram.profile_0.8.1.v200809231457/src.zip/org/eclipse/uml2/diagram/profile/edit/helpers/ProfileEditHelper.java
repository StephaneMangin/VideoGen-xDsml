package org.eclipse.uml2.diagram.profile.edit.helpers;

/**
 * @generated
 */
public class ProfileEditHelper extends UMLBaseEditHelper {
}