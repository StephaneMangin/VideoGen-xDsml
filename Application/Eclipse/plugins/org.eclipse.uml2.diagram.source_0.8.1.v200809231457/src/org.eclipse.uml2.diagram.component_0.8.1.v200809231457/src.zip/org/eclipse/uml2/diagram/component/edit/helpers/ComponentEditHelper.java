package org.eclipse.uml2.diagram.component.edit.helpers;

/**
 * @generated
 */
public class ComponentEditHelper extends UMLBaseEditHelper {
}
