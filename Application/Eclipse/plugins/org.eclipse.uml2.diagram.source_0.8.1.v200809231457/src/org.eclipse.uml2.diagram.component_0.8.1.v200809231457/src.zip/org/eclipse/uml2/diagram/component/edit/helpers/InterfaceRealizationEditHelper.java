package org.eclipse.uml2.diagram.component.edit.helpers;

/**
 * @generated
 */
public class InterfaceRealizationEditHelper extends UMLBaseEditHelper {
}
