package org.eclipse.uml2.diagram.component.edit.helpers;

/**
 * @generated
 */
public class PropertyEditHelper extends UMLBaseEditHelper {
}
