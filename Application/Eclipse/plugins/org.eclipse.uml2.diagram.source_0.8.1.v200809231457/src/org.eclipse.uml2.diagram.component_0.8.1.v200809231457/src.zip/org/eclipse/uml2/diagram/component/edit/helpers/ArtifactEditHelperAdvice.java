package org.eclipse.uml2.diagram.component.edit.helpers;

import org.eclipse.gmf.runtime.emf.type.core.edithelper.AbstractEditHelperAdvice;

/**
 * @generated
 */
public class ArtifactEditHelperAdvice extends AbstractEditHelperAdvice {
}
