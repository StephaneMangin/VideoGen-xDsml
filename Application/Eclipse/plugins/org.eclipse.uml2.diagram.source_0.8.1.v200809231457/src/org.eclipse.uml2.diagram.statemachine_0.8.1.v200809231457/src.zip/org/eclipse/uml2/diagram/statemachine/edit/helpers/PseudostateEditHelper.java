package org.eclipse.uml2.diagram.statemachine.edit.helpers;

/**
 * @generated
 */
public class PseudostateEditHelper extends UMLBaseEditHelper {
}
