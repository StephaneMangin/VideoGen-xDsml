package org.eclipse.uml2.diagram.statemachine.part;

import org.eclipse.gmf.runtime.diagram.ui.parts.DiagramActionBarContributor;

/**
 * @generated
 */
public class UMLDiagramActionBarContributor extends DiagramActionBarContributor {

	/**
	 * @generated
	 */
	protected Class getEditorClass() {
		return UMLDiagramEditor.class;
	}

	/**
	 * @generated
	 */
	protected String getEditorId() {
		return UMLDiagramEditor.ID;
	}
}
