package org.eclipse.uml2.diagram.common.genapi;

import org.eclipse.emf.ecore.EObject;


public interface IUpdaterNodeDescriptor {

	public EObject getModelElement();

	public int getVisualID();	

	public String getType();

}
