/***************************************************************************
 * Copyright (c) 2004 - 2008 Martin Taal and others
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *    Martin Taal - initial API and implementation
 **************************************************************************/
package org.eclipse.emf.cdo.server.internal.hibernate;

import org.eclipse.emf.cdo.common.id.CDOID;
import org.eclipse.emf.cdo.common.id.CDOIDTemp;
import org.eclipse.emf.cdo.common.revision.CDORevision;
import org.eclipse.emf.cdo.server.IStore;
import org.eclipse.emf.cdo.server.hibernate.IHibernateMappingProvider;
import org.eclipse.emf.cdo.server.hibernate.IHibernateStore;
import org.eclipse.emf.cdo.server.hibernate.id.CDOIDHibernate;
import org.eclipse.emf.cdo.spi.common.InternalCDORevision;

import org.hibernate.Session;

import java.util.Map;
import java.util.Properties;

/**
 * @author Martin Taal
 */
public class HibernateUtil
{
  private static final String EXT_POINT = "mappingProviderFactories";

  private static HibernateUtil instance = new HibernateUtil();

  /**
   * @return the instance
   */
  public static HibernateUtil getInstance()
  {
    return instance;
  }

  /**
   * @param instance
   *          the instance to set
   */
  public static void setInstance(HibernateUtil instance)
  {
    HibernateUtil.instance = instance;
  }

  /**
   * @since 2.0
   */
  public IHibernateStore createStore(IHibernateMappingProvider mappingProvider)
  {
    HibernateStore store = new HibernateStore(mappingProvider);
    mappingProvider.setHibernateStore(store);
    return store;
  }

  /**
   * @since 2.0
   */
  public Session getHibernateSession()
  {
    final HibernateStoreReader storeReader = (HibernateStoreReader)HibernateThreadContext
        .getCurrentHibernateStoreAccessor();
    return storeReader.getHibernateSession();
  }

  /** Converts from a Map<String, String> to a Properties */
  public Properties getPropertiesFromStore(IStore store)
  {
    final Properties props = new Properties();
    final Map<String, String> storeProps = store.getRepository().getProperties();
    for (String key : storeProps.keySet())
    {
      props.setProperty(key, storeProps.get(key));
    }

    return props;
  }

  public String getEntityName(CDORevision cdoRevision)
  {
    return cdoRevision.getCDOClass().getName();
  }

  /**
   * Translates a temporary cdoID into a hibernate ID, by finding the object it refers to in the CommitContext and then
   * returning or by persisting the object. Note assumes that the hibernate session and CommitContext are set in
   * HibernateThreadContext.
   */
  public CDOIDHibernate getCDOIDHibernate(CDOID cdoID)
  {
    final CDORevision cdoRevision = getCDORevision(cdoID);
    if (cdoRevision.getID() instanceof CDOIDHibernate)
    {
      return (CDOIDHibernate)cdoRevision.getID();
    }

    final Session session = getHibernateSession();
    if (!(cdoRevision.getID() instanceof CDOIDHibernate))
    {
      session.saveOrUpdate(cdoRevision);
    }
    if (!(cdoRevision.getID() instanceof CDOIDHibernate))
    {
      throw new IllegalStateException("CDORevision " + cdoRevision.getCDOClass().getName() + " " + cdoRevision.getID()
          + " does not have a hibernate cdoid after saving/updating it");
    }

    return (CDOIDHibernate)cdoRevision.getID();
  }

  public InternalCDORevision getCDORevision(Object target)
  {
    // if (target instanceof CDOObject)
    // {
    // return (InternalCDORevision)((CDOObject)target).cdoRevision();
    // }
    // else
    // {
    return (InternalCDORevision)target;
    // }
  }

  /**
   * Gets a current object, first checks the new and dirty objects from the commitcontent. Otherwise reads it from the
   * session.
   */
  public CDORevision getCDORevision(CDOID id)
  {
    if (id.isNull())
    {
      return null;
    }

    if (HibernateThreadContext.isHibernateCommitContextSet())
    {
      final HibernateCommitContext hcc = HibernateThreadContext.getHibernateCommitContext();
      CDORevision revision;
      if ((revision = hcc.getDirtyObject(id)) != null)
      {
        return revision;
      }
      if ((revision = hcc.getNewObject(id)) != null)
      {
        return revision;
      }

      // maybe the temp was already translated
      if (id instanceof CDOIDTemp)
      {
        final CDOID newID = hcc.getCommitContext().getIDMappings().get(id);
        if (newID != null)
        {
          return getCDORevision(newID);
        }
      }
    }

    if (!(id instanceof CDOIDHibernate))
    {
      throw new IllegalArgumentException("Passed cdoid is not an instance of CDOIDHibernate but a "
          + id.getClass().getName() + ": " + id);
    }

    final CDOIDHibernate cdoIDHibernate = (CDOIDHibernate)id;
    final Session session = getHibernateSession();
    return (CDORevision)session.get(cdoIDHibernate.getEntityName(), cdoIDHibernate.getId());
  }

  public CDORevision getCDORevisionNullable(CDOID id)
  {
    if (id.isNull())
    {
      return null;
    }

    if (HibernateThreadContext.isHibernateCommitContextSet())
    {
      final HibernateCommitContext hcc = HibernateThreadContext.getHibernateCommitContext();
      CDORevision revision;
      if ((revision = hcc.getDirtyObject(id)) != null)
      {
        return revision;
      }
      if ((revision = hcc.getNewObject(id)) != null)
      {
        return revision;
      }

      // maybe the temp was already translated
      if (id instanceof CDOIDTemp)
      {
        final CDOID newID = hcc.getCommitContext().getIDMappings().get(id);
        if (newID != null)
        {
          return getCDORevision(newID);
        }
      }
    }

    if (!(id instanceof CDOIDHibernate))
    {
      return null;
    }

    final CDOIDHibernate cdoIDHibernate = (CDOIDHibernate)id;
    final Session session = getHibernateSession();
    return (CDORevision)session.get(cdoIDHibernate.getEntityName(), cdoIDHibernate.getId());
  }
}
