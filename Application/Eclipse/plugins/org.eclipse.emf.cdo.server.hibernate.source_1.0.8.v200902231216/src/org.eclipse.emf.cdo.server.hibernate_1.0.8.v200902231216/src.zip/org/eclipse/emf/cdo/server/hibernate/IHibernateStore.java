/***************************************************************************
 * Copyright (c) 2004 - 2008 Eike Stepper, Germany.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *    Eike Stepper - initial API and implementation
 **************************************************************************/
package org.eclipse.emf.cdo.server.hibernate;

import org.eclipse.emf.cdo.server.ISession;
import org.eclipse.emf.cdo.server.IStore;
import org.eclipse.emf.cdo.server.IView;
import org.eclipse.emf.cdo.server.internal.hibernate.HibernatePackageHandler;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * @author Eike Stepper
 */
public interface IHibernateStore extends IStore
{
  public Configuration getHibernateConfiguration();

  public SessionFactory getHibernateSessionFactory();

  public IHibernateStoreReader getReader(ISession session);

  public IHibernateStoreWriter getWriter(IView view);

  public HibernatePackageHandler getPackageHandler();
}
