/**
 * <copyright>
 * </copyright>
 *
 * $Id: HbAnnotatedEModelElement.java,v 1.5 2007/07/04 19:31:48 mtaal Exp $
 */
package org.eclipse.emf.teneo.hibernate.hbmodel;

import org.eclipse.emf.teneo.annotations.pamodel.PAnnotatedEModelElement;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Hb Annotated EModel Element</b></em>'. <!--
 * end-user-doc -->
 *
 *
 * @see org.eclipse.emf.teneo.hibernate.hbmodel.HbmodelPackage#getHbAnnotatedEModelElement()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface HbAnnotatedEModelElement extends PAnnotatedEModelElement {

} // HbAnnotatedEModelElement
