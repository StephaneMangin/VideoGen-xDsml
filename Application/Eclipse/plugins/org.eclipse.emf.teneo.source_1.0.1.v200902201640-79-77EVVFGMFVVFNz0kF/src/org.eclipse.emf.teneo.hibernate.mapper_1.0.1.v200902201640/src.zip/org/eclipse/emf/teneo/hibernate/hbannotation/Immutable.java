/**
 * <copyright>
 * </copyright>
 *
 * $Id: Immutable.java,v 1.1 2008/07/12 13:10:33 mtaal Exp $
 */
package org.eclipse.emf.teneo.hibernate.hbannotation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Immutable</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emf.teneo.hibernate.hbannotation.HbannotationPackage#getImmutable()
 * @model annotation="teneo/internal/Target 0='EClass' 1='EReference'"
 * @generated
 */
public interface Immutable extends HbAnnotation {
} // Immutable
