/**
 * <copyright>
 * </copyright>
 *
 * $Id: ForceDiscriminator.java,v 1.1 2008/07/12 13:10:34 mtaal Exp $
 */
package org.eclipse.emf.teneo.hibernate.hbannotation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Force Discriminator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emf.teneo.hibernate.hbannotation.HbannotationPackage#getForceDiscriminator()
 * @model annotation="teneo/internal/Target 0='EClass'"
 * @generated
 */
public interface ForceDiscriminator extends HbAnnotation {
} // ForceDiscriminator
