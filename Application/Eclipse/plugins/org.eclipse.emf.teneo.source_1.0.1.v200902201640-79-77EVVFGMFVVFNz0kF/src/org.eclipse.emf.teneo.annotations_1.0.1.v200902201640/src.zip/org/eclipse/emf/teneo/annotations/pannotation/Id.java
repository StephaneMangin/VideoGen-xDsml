/**
 * <copyright>
 * </copyright>
 *
 * $Id: Id.java,v 1.5 2007/07/04 19:28:01 mtaal Exp $
 */
package org.eclipse.emf.teneo.annotations.pannotation;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Id</b></em>'. <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emf.teneo.annotations.pannotation.PannotationPackage#getId()
 * @model annotation="teneo/internal/Target 0='EAttribute'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='AllowedElementType'"
 * @generated
 */
public interface Id extends PAnnotation {

} // Id
